<?php
include "config.php";
$ID = $_GET['id'];
$sql = "DELETE from transaction where transaction_id = '$ID'";
$result = $con->query($sql);
header("refresh:0;url=transaction.php");
?>