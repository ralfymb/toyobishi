<?php

include "config.php";
error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
</head>
<body>
<link rel=stylesheet href=global.css>
<form method=POST action=>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
<center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>
<div class="mainHeader">
<a href='category_add.php' style='text-decoration: none;'><font class="Add">+ Add New Category</a></font>
<div class="subHeader"> 
</div>
<div class="main">
<center><input id="Search" type="text" class="search form-control" placeholder="Search Here"></center>
    <table id="myTable">
        <thead>
        <tr>
        <th>Category ID
        <th>Category Name
        <th>Category Refund
        <th>Action
        </tr>
        </thead>
        <tbody>
        <?php

        $sql = "Select * from categories";
        $result = $con -> query($sql);

        while($row = $result-> fetch_assoc()){
        ?>
        <tr>
        <td><?php echo $row['category_id']; ?>
        <td><?php echo $row['category_name']; ?>
        <td><?php echo $row['category_refund']; ?>
        <td><?php echo "<a href='category_edit.php?id=".$row['category_id']."' style='text-decoration: none;'><font id=EditBtn>Edit</font></a>"; }?>
        </tbody></table>
</div>
</div>
</body>
</form>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('.search').on('keyup',function(){
        var searchTerm = $(this).val().toLowerCase(); //remove .toLowerCase() if is equals to what typed
        $('#myTable tbody tr').each(function(){
            var lineStr = $(this).text().toLowerCase();
            if(lineStr.indexOf(searchTerm) === -1){
                $(this).hide();
            }else{
                $(this).show();
            }
        });
    });
});
</script>