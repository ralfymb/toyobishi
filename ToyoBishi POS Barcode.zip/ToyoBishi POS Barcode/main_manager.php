<?php

include "config.php";

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
<title>HOME</title>
</head>
<body>
<link rel=stylesheet href=home.css>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>
<?php 
$sqlmonth = "select COUNT(sales_profit) AS 'COUNT' from sales where MONTH(sales_date) = MONTH(NOW())";
$resultmonth = $con->query($sqlmonth);
$rowmonth = $resultmonth->fetch_assoc();
$count = $rowmonth['COUNT'];
?>
<div class=box1>
    Sales This Month: <br><br>
    <b><?php echo $count;?></b>
</div>
<?php 
$sql = "Select * from products";
$result = $con -> query($sql);
$i = 0;
while($row = $result-> fetch_assoc()){
    if($row['product_quantity'] < 15) {
        $i++;
    }
}
?>
<div class=box2>
    No of Critical Level Items: <br>
    <b><?php echo $i; ?></b>
</div>
<div class="chartCard">
      <div class="chartBox">
        Start Date: <input type="date" onchange="startDateFilter(this)" value="<?=date('Y-m-d', strtotime('+0 days'))  ?>"><br>
        End Date: <input type="date" onchange="endDateFilter(this)" value="<?=date('Y-m-d', strtotime('+0 days'))  ?>">
        <canvas id="myChart"></canvas>
      </div>
    </div>
    <?php 
        //$sql = "Select * from sales";S
        $sql = "SELECT sales_status, DATE(sales_date) AS 'DAY', SUM(sales_profit) AS 'SUM' FROM sales WHERE sales_status = 'Transacted' GROUP BY DAY(sales_date), DAY(sales_date)";
        $result = $con->query($sql);

            while($row = $result->fetch_assoc()){
                $dateArray[] = $row['DAY'];
                $priceArray[] = $row['SUM'];
            }
        unset($con);
    ?>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>        

    <script>
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    today = mm + '/' + dd + '/' + yyyy;

    const dateArrayJS = <?php echo json_encode($dateArray); ?>;
    const dateChartJS = dateArrayJS.map((day, index) => {
        let dayjs = new Date(day);
        return dayjs.setHours(0, 0, 0, 0);
    })

    // setup 
    const data = {
      labels: dateChartJS,
      datasets: [{
        label: 'Profit per Day ₱',
        data: <?php echo json_encode($priceArray)?>,
        backgroundColor: [
          'rgba(255, 26, 104, 0.2)',
        ],
        borderColor: [
          'rgba(255, 26, 104, 1)',
        ],
        borderWidth: 1
      }]
    };

    // config 
    const config = {
      type: 'bar',
      data,
      options: {
        autoSkip: false,
        scales: {
          x: {
            min: today,
            max: today,
            type: 'time',
            time: {
                unit: 'day'
          }
        },
          y: {
            beginAtZero: true
          }
        }
      }
    };

    // render init block
    const myChart = new Chart(
      document.getElementById('myChart'),
      config
    );
    function startDateFilter(date){
        const startDate = new Date(date.value);
        myChart.config.options.scales.x.min = startDate.setHours(0, 0, 0, 0);
        myChart.update();
    }

    function endDateFilter(date){
        const endDate = new Date(date.value);
        myChart.config.options.scales.x.max = endDate.setHours(0, 0, 0, 0);
        myChart.update();
    }
    </script>

    

</body>
</html>

