<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<?php

include "config.php";

if(!$con->connect_error){
	echo "Connected";
}

if(isset($_POST['sub'])){

    $sid = $_POST['sid'];
	$sname = $_POST['sname'];
    $scon = $_POST['scon'];
    $semail = $_POST['semail'];
	$sstatus = $_POST['sstatus'];
	
	$sql ="UPDATE supplier SET supplier_name = '$sname', supplier_contact = '$scon', supplier_email = '$semail', supplier_status = '$sstatus' where supplier_id = $sid ";
	$result = $con->query($sql);
	
	if($result == True){
		$fulln = "$firstn $lastn";
        $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Edit Supplier ID: $sid',NOW())";
        $insertlog = $con->query($sqllog);
	?>
	<script>
	alert("Successfully Updated")
	</script>
	<?php
	header("refresh:0;url=supplier_list.php");
	}else{
		echo $con->error;
	}
}

?>