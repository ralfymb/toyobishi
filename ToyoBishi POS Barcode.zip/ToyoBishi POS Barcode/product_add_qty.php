<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];

$ID = $_GET['id'];
$sql = "Select * from products where product_id = '$ID'";
$result = $con->query($sql);

$row = $result->fetch_assoc();

$epid = $row['product_id'];
$epname = $row['product_name'];
$epquan = $row['product_quantity'];
$epprice = $row['product_price'];
$epcategory = $row['product_category'];
$epstatus = $row['product_status'];

?>
<html>
<head>
</head>
<body>
<form method =POST action=product_add_qty_final.php>
<link rel=stylesheet href=crud.css>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>

<div class="mainHeader">
    Add Quantity
</div>

<div class="main">
    <input type=hidden name=pid value="<?php echo $epid;?>" readonly>
    <font class="font1">
    Product Name: <br> <?php echo "<input type=text value='$epname' name=pname readonly>"; ?>
    <br><br>
    Add Quantity: <div class="tooltip"><img style="filter:invert(100%);width:1.5vw;height:1.5vw;" src=img/tooltip.png><span class="tooltiptext">Add(not set) quantity</span></div> <br> <input type=number name=pquantity>
    <br><br>
    Product Cost: <div class="tooltip"><img style="filter:invert(100%);width:1.5vw;height:1.5vw;" src=img/tooltip.png><span class="tooltiptext">Price paid for product</span></div> <br> <div class=currency><input style="width:11.5vw;" type=number name=pcost step=0.01></div>
    <br>
    Product Price: <div class="tooltip"><img style="filter:invert(100%);width:1.5vw;height:1.5vw;" src=img/tooltip.png><span class="tooltiptext">Set price for product</span></div> <br> <div class=currency><input style="width:11.5vw;" type=number name=pprice step=0.01></div>
    <br>
    Supplier: <br> <select style="font-size:1vw;font-family:sans-serif" name='psuppliers'><?php $sql2 = "Select supplier_name from supplier WHERE supplier_status = 'active'";
        $result2 = $con -> query($sql2); 
        while($row2 = $result2-> fetch_assoc()){ $supp = $row2['supplier_name']; echo "<option value=".$supp.">$supp</option>"; }?></select>
    <br><br>
    <input type=submit name=sub value="Add Quantity" style="font-family:sans-serif;">
</div>
</form>
</body>
</html>