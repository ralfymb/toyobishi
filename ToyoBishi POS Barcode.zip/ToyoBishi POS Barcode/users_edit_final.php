<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<?php

include "config.php";

if(!$con->connect_error){
	echo "Connected";
}

if(isset($_POST['sub'])){

    $id = $_POST['uid'];
	$firstname = $_POST['ufname'];
    $lastname = $_POST['ulname'];
    $username = $_POST['uuname'];
	$password = $_POST['upass'];
	$position = $_POST['pos'];
	
	$sql ="UPDATE users SET user_firstname = '$firstname', user_lastname = '$lastname', user_username = '$username', user_password = '$password', user_position = '$position' where user_id = $id ";
	$result = $con->query($sql);
	
	if($result == True){
		$fulln = "$firstn $lastn";
        $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Edit User ID: $id',NOW())";
        $insertlog = $con->query($sqllog);
	?>
	<script>
	alert("Successfully Updated")
	</script>
	<?php
	header("refresh:0;url=users_list.php");
	}else{
		echo $con->error;
	}
}

?>