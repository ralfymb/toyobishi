<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
$fulln = "$firstn $lastn";
?>
<html>
<head>
</head>
<body>
<form method =POST action=supplier_add.php>
<link rel=stylesheet href=crud.css>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
<center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>

<div class="mainHeader">
    Add New Supplier
</div>

<div class="main">
    <font class="font1">
    Supplier Name: <br> <input type=text name=sname>
    <br><br>
    Supplier Contact: <br> <input type=number name=scontact>
    <br><br>
    Supplier Email: <br> <input type=text name=semail>
    <br><br>
    Supplier Status: </font><br> <input type=radio value="active" name=sstatus checked> <font class="font2">Active</font> <br> <input type=radio value="inactive" name=sstatus> <font class="font2">Inactive</font> 
    <br><br>
    <input type=submit name=sub value="Add New Supplier" style="font-family:sans-serif;">
</div>
</form>
</body>
</html>

    <?php

    include "config.php";

    if(isset($_POST['sub'])){

    $sname = $_POST['sname'];
    $scontact = $_POST['scontact'];
    $semail = $_POST['semail'];
    $sstatus = $_POST['sstatus'];

    $sql = "Insert into supplier(supplier_name,supplier_contact,supplier_email,supplier_status) values ('$sname','$scontact','$semail','$sstatus')";
    if(!$sname || !$scontact || !$semail || !$sstatus){
        ?>
    <script>
        alert("Textfield can't be empty!")
    </script>
    <?php
    }else

    $insert = $con->query($sql);
    $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Refunded Product ID: $sname',NOW())";
    $insertlog = $con->query($sqllog);

    echo $sname;

    if($insertlog ==  True){
    ?>
    <script>
        alert("Successfully Added!")
    </script>
    <?php
    }
    //header("refresh:0;url=supplier_list.php");
    }

    ?>