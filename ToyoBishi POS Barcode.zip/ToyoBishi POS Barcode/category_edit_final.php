<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<?php

include "config.php";

if(!$con->connect_error){
	echo "Connected";
}

if(isset($_POST['sub'])){

	$ccatorigname = $_POST['origname'];
    $ccatid = $_POST['catid'];
	$ccatname = $_POST['catname'];
    $ccatref = $_POST['catref'];

	//echo $ccatorigname;
	//echo $ccatname;
	
	$sql ="UPDATE categories SET category_name = '$ccatname', category_refund = '$ccatref' where category_id = $ccatid ";
	$result = $con->query($sql);

	$sqlprd ="UPDATE products SET product_category = '$ccatname' where product_category = '$ccatorigname' ";
	$resultprd = $con->query($sqlprd);
	
	if($resultprd == True){
		//echo "test";
		$fulln = "$firstn $lastn";
        $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Edit Category ID: $ccatid',NOW())";
        $insertlog = $con->query($sqllog);
	?>
	
	<?php
	header("refresh:0;url=category_list.php");
	}else{
		echo $con->error;
	}
}

?>