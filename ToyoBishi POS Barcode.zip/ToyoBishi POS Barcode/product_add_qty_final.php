<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<?php

include "config.php";

if(!$con->connect_error){
	echo "Connected";
}

if(isset($_POST['sub'])){

    $pid = $_POST['pid'];
	$pname = $_POST['pname'];
    $pprice = $_POST['pprice'];
    $pcost = $_POST['pcost'];
    $pquantity = $_POST['pquantity'];
	$psuppliers = $_POST['psuppliers'];

	$sqli = "Select * from products where product_id = $pid";
	$resulti = $con->query($sqli);
	$rowi = $resulti->fetch_assoc();
	$prdquan = $rowi['product_quantity'];
	$quan = $prdquan + $pquantity;
	
	$sql ="UPDATE products SET product_cost = $pcost, product_quantity = '$quan', product_price = '$pprice' where product_id = $pid ";
	$result = $con->query($sql);
	
	$sql1 = "Insert into inventory(product_id,inventory_quantity,inventory_input,inventory_cost,inventory_status,inventory_date) values ($pid,$quan,$pquantity,$pcost,'Supplier: $psuppliers',NOW())";
	$insert1 = $con->query($sql1);

	if($result == True){
	$fulln = "$firstn $lastn";
	$sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Added $quan Quantity for: $pname',NOW())";
	$insertlog = $con->query($sqllog);
	?>
	<script>
	alert("Successfully Updated")
	</script>
	<?php
	header("refresh:0;url=product_list.php");
	}else{
		echo $con->error;
	}
}

?>