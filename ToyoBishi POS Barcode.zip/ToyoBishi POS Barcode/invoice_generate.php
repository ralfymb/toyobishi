<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
$fulln = "$firstn $lastn";
?>

<html>
<head><title>INVOICE</title>
</head>
<body>
<form method=POST action=>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<link rel=stylesheet href=invoice.css>

<body>
<?php
$or_number = $_GET['id'];
?>
<center>
<div id="pdf" class="invoice">
		<div class="company-address">
			<b>ToyoBishi Automotive Parts Trading</b>
			<br />
			73, 1113 E Rodriguez Sr. Ave
			<br />
			Quezon City, Metro Manila
			<br />
            TEL: 8361-7556
            <br />
		</div>
	
		<div class="invoice-details">
		</div>
		
		<div class="customer-address">
            <b>Cashier: </b> <?php echo $fulln ?>
            <br><b>OR No: </b> <?php echo $or_number?>
		</div>
		
		<div class="clear-fix"></div>
			<table border='1' cellspacing='0'>
        
        <th width=250>Item/s
        <th width=80>Quantity
        <th width=100>Unit price
        <th width=100>Total price
                 
        <?php 
        $sql3 = "Select * from invoice WHERE or_number = $or_number";
        $result3 = $con -> query($sql3);
        while($row3 = $result3-> fetch_assoc()){
            $cash = $row3['invoice_cash'];
        ?>
        <tr>
        <td> <?php echo $row3['product_name']; ?>
        <td class='text-center'> <?php echo $row3['product_quantity']; ?>
        <td class='text-right'>₱<?php echo number_format($row3['product_price'],2); ?>
        <?php $rowtotal = $row3['product_quantity'] * $row3['product_price']; ?>
        <td class='text-right'>₱<?php echo number_format($rowtotal,2); ?>
        </tbody>
        <?php
        if (!isset($total))
        {
        $total = NULL;//or use a "valuestring"
        }
        $total = $total + $rowtotal; } ?>
        <tr>
        <td colspan='3' class='text-right'><b>Total</b></td>
        <td class='text-right'><b>₱<?php echo number_format($total,2); ?></b></td>
        <tr>
        <td colspan='3' class='text-right'><b>Cash</b></td>
        <td class='text-right'><b>₱<?php echo number_format($cash,2); ?></b></td>
        <tr>
        <td colspan='3' class='text-right'><b>Change</b></td>
        <?php $change = $cash - $total?>
        <td class='text-right'><b>₱<?php echo number_format($change,2);  ?></b></td>
    </table>
    </div>
    <br><br>
    <button type=submit formaction="invoice_list.php"><< BACK</button>
    <button onclick="printDiv('pdf','Invoice')">PRINT</button>
</body>
</form>
</html>

    <script>
        var doc = new jsPDF();

        function printDiv(divId, title) {

        let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=150');

        mywindow.document.write(`<html><head><title>${title}</title>`);
        mywindow.document.write('</head><body >');
        mywindow.document.write(document.getElementById(divId).innerHTML);
        mywindow.document.write('</body></html>');

        mywindow.document.close(); // necessary for IE >= 10
        mywindow.focus(); // necessary for IE >= 10*/

        mywindow.print();
        mywindow.close();

        return true;
    }
    </script>
