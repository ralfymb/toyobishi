<?php

include "config.php";
error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
</head>
<body>
<link rel=stylesheet href=global.css>
<form method=POST action=>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>
<div class="mainHeader">
<a href='supplier_add.php' style='text-decoration: none;'><font class="Add">+ Add New Supplier</a></font>
<div class="subHeader"> 
Active<input type="radio" name="status" value="active" checked>
Inactive<input type="radio" name="status" value="inactive">
<input type=submit name=submit value="Sort" style="font-family:sans-serif;">
</div>
<div class="main">
<center><input id="Search" type="text" class="search form-control" placeholder="Search Here"></center>
    <table id="myTable">
        <thead>
        <tr>
        <th>Supplier ID
        <th>Supplier Name
        <th>Supplier Contact
        <th>Supplier Email
        <th>Supplier Status
        <th>Action
        </tr>
        </thead>
        <tbody>
        <?php
        if(isset($_POST['submit'])){
        $status = $_POST['status'];

        if($status == "active") {          
            $stat = 'active';
        }
        elseif($status == "inactive"){
            $stat = 'inactive';
        } }

        if(empty($stat)){
        $sql = "Select * from supplier WHERE supplier_status = 'active'";
        $result = $con -> query($sql);
        }else

        $sql = "Select * from supplier WHERE supplier_status = '$stat'";
        $result = $con -> query($sql);

        while($row = $result-> fetch_assoc()){
        ?>
        <tr>
        <td><?php echo $row['supplier_id']; ?>
        <td><?php echo $row['supplier_name']; ?>
        <td><?php echo $row['supplier_contact']; ?>
        <td><?php echo $row['supplier_email']; ?>
        <td><?php echo $row['supplier_status']; ?>
        <td><?php if($row['supplier_status'] == "active"){  echo "<a href='supplier_archive.php?id=".$row['supplier_id']."' style='text-decoration: none;'><font id=ArchiveBtn>Archive</font></a>"; }else if($row['supplier_status'] == "inactive"){ echo "<a href='supplier_archive.php?id=".$row['supplier_id']."' style='text-decoration: none;'><font id=ArchiveBtn>Unarchive</font></a>"; } echo "<a href='supplier_edit.php?id=".$row['supplier_id']."' style='text-decoration: none;'><font id=EditBtn>Edit</font></a>"; }?>
        </tbody></table>
</div>
</div>
</body>
</form>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('.search').on('keyup',function(){
        var searchTerm = $(this).val().toLowerCase(); //remove .toLowerCase() if is equals to what typed
        $('#myTable tbody tr').each(function(){
            var lineStr = $(this).text().toLowerCase();
            if(lineStr.indexOf(searchTerm) === -1){
                $(this).hide();
            }else{
                $(this).show();
            }
        });
    });
});
</script>