<?php
include "config.php";
$barcodeno = $_GET['id'];
$sql1 = "Select * from transaction WHERE product_barcode = '$barcodeno'";
    $result1 = $con -> query($sql1);
    while($row = $result1-> fetch_assoc()){
        $tpid = $row['product_id'];
        $tquan = $row['product_amount'];
    }

$sql2 = "Select * from products WHERE product_id = $tpid";
    $result2 = $con -> query($sql2);
    while($row = $result2-> fetch_assoc()){
        $pid = $row['product_id'];
        $pquantity = $row['product_quantity'];
    }

$tquan = $tquan - 1;

if($tquan <= 0){
    //nothing happens if less than 1
}else{
    $sql3 ="UPDATE transaction SET product_amount = $tquan where product_id = $tpid ";
    $result3 = $con->query($sql3);
}

header("refresh:0;url=transaction.php");
?>