<?php

include "config.php";
error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
</head>
<body>
<link rel=stylesheet href=transaction.css>
<form method=POST>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
<center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>
<div class="mainHeader">
<input type=text placeholder="Enter Barcode Here" autofocus name=barcodeno>
<br><input type=submit style="display:none;" formaction="transaction.php" name=sub value='Add Item'> <!--<input type="number" min="1" oninput="this.value = Math.abs(this.value+1) //qwuantity">-->
</div>
<div class="main">
    <table>
        <th>Barcode
        <th>Product ID
        <th>Product Name
        <th>Product Price
        <th>Product Amount
        <th>Total
        <th>Action
        <?php

        if(isset($_POST['sub'])){

            $barcodeno = $_POST['barcodeno'];
            error_reporting(0);

            $sql1 = "Select * from products WHERE product_barcode = '$barcodeno'";
            $result1 = $con->query($sql1);
            while($row = $result1-> fetch_assoc()){
                $pname = $row['product_name'];
                $bno = $row['product_barcode'];
                $pid = $row['product_id'];
                $prdquan = $row['product_quantity'];
                $pprice = $row['product_price'];
            }

            $sqlamm = "Select * from transaction WHERE product_barcode = '$barcodeno'";
            $resultamm = $con -> query($sqlamm);
            while($row = $resultamm-> fetch_assoc()){ 
                $amm = $row['product_amount'];
                $tpid = $row['product_id'];
            }

            $sql2 = "Select * from products WHERE product_barcode = '$barcodeno'";
            $result2 = $con -> query($sql2);
            while($row = $result2-> fetch_assoc()){
                $pid = $row['product_id'];
                $pquantity = $row['product_quantity'];
                $pstat = $row['product_status'];
            }

            $duplicate=mysqli_query($con,"select * from transaction where product_barcode = '$barcodeno'");

            if($pstat == 'inactive'){
                ?>
                <script>
                alert("That product is inactive!")
                </script>
                <?php
                header("refresh:0;url=transaction.php");
                return 0;
            }

            if(mysqli_num_rows($duplicate)>0)
            {
            
            $amm = $amm + 1;
            if($amm > $pquantity){
                //nothing happens if out of stock - khurt babaji time
                header("refresh:0;url=transaction.php");
            }
            else{
                $sql3 ="UPDATE transaction SET product_amount = $amm where product_id = $tpid ";
                $result3 = $con->query($sql3);
                header("refresh:0;url=transaction.php");
            }
            }else{
                $sql2 = "Insert into transaction(product_barcode,product_id,product_name,product_price,product_amount) values ('$bno',$pid,'$pname',$pprice,'1')";
                $insert = $con->query($sql2); 
            }


            // check quantity if in stock

        }
        $sql3 = "Select * from transaction";
        $result3 = $con -> query($sql3);
        while($row = $result3-> fetch_assoc()){
            $pdid = $row['product_id'];
            $rowtotal = $row['product_amount'] * $row['product_price'];
            $sql4 = "Select * from products WHERE product_id = $pdid";
            $result4 = $con->query($sql4);
            $row4 = $result4->fetch_assoc();
            $pdquan = $row4['product_quantity'];
        ?>
        <tr>
        <td><?php echo $row['product_barcode']; ?>
        <td><?php echo $row['product_id']; ?>
        <td><?php echo $row['product_name']; ?>
        <td>₱<?php echo $row['product_price']; ?>
        <td><?php echo "<a href='transaction_minus.php?id=".$row['product_barcode']."' style='text-decoration: none;'><font id=MinusBtn>-</font></a> "; ?> <input id=NumberAmount type=number max=<?php echo $pdquan; ?> value='<?php echo $row['product_amount']?>'> <?php echo " <a href='transaction_plus.php?id=".$row['product_barcode']."' style='text-decoration: none;'><font id=AddBtn>+</font></a>"; ?>
        <td>₱<?php echo number_format($rowtotal,2); ?>
        <td><?php echo "<a href='transaction_remove.php?id=".$row['transaction_id']."' style='text-decoration: none;'><font id=RemoveBtn>Remove</font></a>"; //add remove and quantity ?>
        <?php $total = $total + $rowtotal; ?>
        <?php } ?>
    </table>
        <table>
        <td>CASH: ₱<input type=number step=".01" style=font-size:1.15vw; name=cash>
        <td>TOTAL: ₱<?php echo number_format($total,2) ?>
        <td><button type=submit formaction="invoice.php" name=invoice>PROCEED >></button>
        </table>
</div>
</body>
</html>
<!--
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        var srt = null;
        $("input[type=text]").on("keyup", function() {
            srt != null && clearTimeout(srt);
            srt = setTimeout(function(){
                $("input[type=submit]").click();
            }, 500);
        });
    });
</script>
-->