<html>
    <head><title>BARCODE</title></head>
<body>
<link rel=stylesheet href=barcode.css>

<script src="Scripts/jquer_latest_2.11_.min.js" type="text/javascript"></script>
<script src="Scripts/html2canvas.js" type="text/javascript"></script>

<?php

include "config.php";
include "product_barcode_generate.php";

$barcode = $_GET['barcode'];

$count=0;
echo "<table>";
echo "<div id='pdf'>";
echo "<center><div id='printed'>";
for($i=0;$i<160;$i++){
$count=$count+1;
echo "<th> "; echo bar128($barcode);
echo "<th> ";
if($count%80==0)
  {
    echo"</tr>";
  }
}
echo "</div>";
echo "</table>";

?>
<center>
<input type="button" value="Preview & Convert" id="btnConvert" >
</center>

<script>
    $(document).ready(function () {
    $("#btn_convert").on('click', function () {
		html2canvas(document.getElementById("pdf"),		{
			allowTaint: true,
			useCORS: true
		}).then(function (canvas) {
			var anchorTag = document.createElement("a");
			document.body.appendChild(anchorTag);
			document.getElementById("previewImg").appendChild(canvas);			anchorTag.download = "filename.jpg";
			anchorTag.href = canvas.toDataURL();
			anchorTag.target = '_blank';
			anchorTag.click();
		});
    });
});
</script>

</body>
</html>