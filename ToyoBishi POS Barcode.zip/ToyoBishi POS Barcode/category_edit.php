<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];

$ID = $_GET['id'];

$sql = "Select * from categories where category_id = '$ID'";
$result = $con->query($sql);

$row = $result->fetch_assoc();

$catid = $row['category_id'];
$catname = $row['category_name'];
$catref = $row['category_refund'];

$con->close();

?>
<html>
<head>
</head>
<body>
<form method =POST action=category_edit_final.php>
<link rel=stylesheet href=crud.css>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
<center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>

<div class="mainHeader">
    Edit Category
</div>

<div class="main">
    <input type=hidden name=catid value="<?php echo $catid;?>" readonly>
    <input type=hidden name=origname value="<?php echo $catname;?>" readonly>
    <font class="font1">
    Category Name: <br> <input type=text name=catname value=<?php echo $catname;?>>
    <br><br>
    Category Refund: </font> <br> 
    <?php
    if($catref == 'Yes'){
        ?> <input type=radio value="Yes" name=catref checked> <font class="font2">Yes</font> <br> <input type=radio value="No" name=catref> <font class="font2">No</font> <?php
    }if($catref == 'No'){
        ?> <input type=radio value="Yes" name=catref> <font class="font2">Yes</font> <br> <input type=radio value="No" name=catref checked> <font class="font2">No</font> <?php } ?>
    <br><br>
    <input type=submit name=sub value="Update Record" style="font-family:sans-serif;">
</div>
</form>
</body>
</html>