<?php
include "config.php";
$ID = $_GET['pr_id'];
$or_no = $_GET['or_number'];

$sql = "Select * from invoice WHERE product_id = $ID AND or_number = '$or_no'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$stat = $row['invoice_status'];
session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$fulln = "$firstn $lastn";

if($stat == 'Transacted'){
    $sql = "Update invoice SET invoice_status='Refunded' where product_id = '$ID' AND or_number = '$or_no'";
    $sql1 = "Update sales SET sales_status='Refunded' where product_id = '$ID' AND or_number = '$or_no'";
    $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Refunded Product ID: $ID',NOW())";
}else if($stat == 'Refunded'){
    echo "test";
    $sql = "Update invoice SET invoice_status='Transacted' where product_id = '$ID' AND or_number = '$or_no'";
    $sql1 = "Update sales SET sales_status='Transacted' where product_id = '$ID' AND or_number = '$or_no'";
    $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Unrefunded Product ID: $ID',NOW())";
}
$result = $con->query($sql);
$result1 = $con->query($sql1);
$insertlog = $con->query($sqllog);
header("refresh:0;url=invoice_report.php?id=$or_no");
?>