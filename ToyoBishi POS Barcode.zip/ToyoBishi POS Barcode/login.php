<?php

include "config.php";
?>
<html>
<head>
</head>
<body>
<link rel=stylesheet href=login.css>
<form method=POST action=login.php>
<div class=loginDiv>
    <img src=img/toyobishi.png style="width:13vw;height:8vw;">
    <p><b>Username</b></p>
    <input type=text name=user placeholder="Enter Username" required>
    <p><b>Password</b></p>
    <input type=password name=pass placeholder="Enter Password" required>
    <div id=submitDiv><input type=submit name=sub value="LOGIN" style="font-family:sans-serif;">
</div>

<?php

if(isset($_POST['sub'])){
	$user = $_POST['user'];
    $pass = $_POST['pass'];

    $sql = "Select * from users WHERE BINARY user_username = '$user' AND user_password = '$pass'";
	
	$result = $con->query($sql);

if($result -> num_rows == 0) {
    echo "<font style=color:red;font-family:sans-serif;font-size:.75vw;><b><center>Incorrect Username or Password</center></b></font></div>";
}
elseif($result -> num_rows > 0){
	$row = $result->fetch_assoc();
	$pos = $row['user_position'];
	$id = $row['user_id'];
	$usr = $row['user_username'];
	$pss = $row['user_password'];
	$usr1 = "Select user_username from users";
	$pss1 = "Select user_password from users";
	$stat = $row['user_status'];
	$fname = "Select user_firstname from users WHERE user_username = '$usr'";
	if($stat == 'Inactive'){
		echo "<font style=color:red;font-family:sans-serif;font-size:.75vw;><b><center>User is Inactive</center></b></font></div>";
		}else
	if($user === $usr && $pass === $pss){
		
        $sqllog = "Insert into logs(log_user,log_action,log_date) values ('Username: $usr','Logged In',NOW())";
        $insertlog = $con->query($sqllog);
		session_start();
		$userid = $id;
		$_SESSION['userid']=$userid;
		$usernm = $usr;
		$_SESSION['usernm']=$usernm;
		$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
		$result = $con->query($sql);
		$row = $result->fetch_assoc();
		$posn = $row['user_position'];
		if($posn == "Manager"){
		header("refresh:0;url=main_manager.php");
		}
		if($posn == "Admin"){
		header("refresh:0;url=users_list.php");
		}
		if($posn == "Employee"){
		header("refresh:0;url=transaction.php");
		}
		
	}else{
		?>
  	<script>
	alert("Username or Password is incorrect!")
  	</script>
  	<?php
  	header("refresh:0;url=login.php");
	}
}

$con->close();
}
?>

</body>
</form>
</html>