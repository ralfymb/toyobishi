-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2022 at 03:36 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `system`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_refund` varchar(55) NOT NULL COMMENT 'yes / no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_refund`) VALUES
(1, 'CAT', 'Yes'),
(2, 'TAC', 'No'),
(3, 'TCA', 'Yes'),
(4, 'OCR', 'Yes'),
(5, 'GORR', 'No'),
(6, 'NER', 'Yes'),
(7, 'TRR', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `inventory_quantity` int(55) NOT NULL,
  `inventory_cost` decimal(10,2) NOT NULL,
  `inventory_input` varchar(55) DEFAULT NULL,
  `inventory_output` varchar(55) DEFAULT NULL,
  `inventory_status` varchar(55) NOT NULL,
  `inventory_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `product_id`, `inventory_quantity`, `inventory_cost`, `inventory_input`, `inventory_output`, `inventory_status`, `inventory_date`) VALUES
(1, 1, 10, '100.00', '10', NULL, 'Supplier: Supplier', '2022-05-02 05:55:28'),
(2, 2, 20, '50.00', '20', NULL, 'Supplier: Supplier', '2022-05-02 05:59:24'),
(3, 3, 150, '100.00', '150', NULL, 'Supplier: Supplier', '2022-05-02 06:04:59'),
(4, 4, 120, '100.00', '120', NULL, 'Supplier: Supplier', '2022-05-02 06:06:58'),
(5, 5, 123, '120.00', '123', NULL, 'Supplier: Supplier', '2022-05-03 07:24:25'),
(6, 2, 25, '55.00', '5', NULL, 'Supplier: Supplier', '2022-05-23 01:38:51'),
(7, 6, 100, '101.00', '100', NULL, 'Supplier: qwe', '2022-06-01 22:53:36'),
(8, 7, 5, '100.75', '5', NULL, 'Supplier: suppz', '2022-06-01 22:59:39'),
(9, 2, 5, '50.00', '1', NULL, 'Supplier: suppz', '2022-06-02 04:28:55'),
(10, 7, 6, '70.00', '1', NULL, 'Supplier: suppz', '2022-06-02 04:29:44'),
(11, 5, 11, '50.00', '1', NULL, 'Supplier: suppz', '2022-06-02 04:42:14'),
(12, 2, 2, '50.00', NULL, '3', 'Cashier: Patrick De Guzman', '2022-06-03 05:20:42'),
(13, 2, 1, '50.00', NULL, '1', 'Cashier: Patrick De Guzman', '2022-06-03 05:22:15'),
(14, 6, 4, '0.00', NULL, '4', 'Cashier: Summer Car', '2022-06-03 22:37:15'),
(15, 6, 1, '0.00', NULL, '1', 'Cashier: Summer Car', '2022-06-03 22:37:35'),
(16, 6, 1, '0.00', NULL, '1', 'Cashier: Summer Car', '2022-06-03 22:39:05'),
(17, 6, 1, '0.00', NULL, '2', 'Cashier: Summer Car', '2022-06-03 22:39:44'),
(18, 8, 30, '3000.00', '30', NULL, 'Supplier: Supplier', '2022-06-04 15:44:33'),
(19, 6, 1, '0.00', NULL, '2', 'Cashier: Summer Car', '2022-06-06 01:52:56'),
(20, 6, 2, '0.00', NULL, '3', 'Cashier: Summer Car', '2022-06-06 01:54:35'),
(21, 6, 1, '0.00', NULL, '3', 'Cashier: Summer Car', '2022-06-06 01:59:00'),
(22, 13, 17, '425.00', '17', NULL, 'Supplier: Supplier', '2022-06-13 23:51:19'),
(23, 14, 21, '600.00', '21', NULL, 'Supplier: Supplier', '2022-06-13 23:52:43'),
(24, 15, 31, '450.00', '31', NULL, 'Supplier: Supplier', '2022-06-13 23:53:16'),
(25, 11, 1, '550.00', NULL, '1', 'Cashier: Summer Car', '2022-06-14 20:57:06'),
(26, 11, 0, '550.00', NULL, '1', 'Cashier: Summer Car', '2022-06-14 20:57:53'),
(27, 11, 2, '550.00', NULL, '2', 'Cashier: Summer Car', '2022-06-14 20:58:57'),
(28, 15, 30, '450.00', NULL, '1', 'Cashier: Patrick De Guzman', '2022-06-14 21:27:55'),
(29, 15, 29, '450.00', NULL, '1', 'Cashier: Patrick De Guzman', '2022-06-14 21:31:44'),
(30, 15, 28, '450.00', NULL, '1', 'Cashier: Patrick De Guzman', '2022-06-14 21:33:39'),
(31, 15, 31, '470.00', '3', NULL, 'Supplier: Supplier', '2022-06-14 21:35:29'),
(32, 15, 32, '500.00', '1', NULL, 'Supplier: Supplier', '2022-06-14 21:36:22');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `or_number` int(11) NOT NULL,
  `invoice_cashier` varchar(55) NOT NULL,
  `invoice_date` datetime NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `invoice_cash` decimal(10,2) NOT NULL,
  `invoice_status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`or_number`, `invoice_cashier`, `invoice_date`, `product_id`, `product_name`, `product_price`, `product_quantity`, `invoice_cash`, `invoice_status`) VALUES
(1, 'Summer Car', '2022-06-02 19:29:48', 2, 'test1', '100.00', 1, '150.00', 'Transacted'),
(2, 'Summer Car', '2022-06-03 02:38:55', 2, 'test1', '100.00', 1, '230.00', 'Transacted'),
(2, 'Summer Car', '2022-06-03 02:38:55', 6, 'tesz', '126.00', 1, '230.00', 'Transacted'),
(3, 'Summer Car', '2022-06-03 02:57:48', 6, 'tesz', '126.00', 1, '155.00', 'Transacted'),
(4, 'Patrick De Guzman', '2022-06-03 05:20:42', 2, 'test1', '100.00', 3, '350.00', 'Transacted'),
(5, 'Patrick De Guzman', '2022-06-03 05:22:15', 2, 'test1', '100.00', 1, '100.00', 'Transacted'),
(6, 'Summer Car', '2022-06-03 22:37:15', 6, 'tesz', '126.00', 4, '505.00', 'Transacted'),
(7, 'Summer Car', '2022-06-03 22:37:35', 6, 'tesz', '126.00', 1, '126.00', 'Transacted'),
(8, 'Summer Car', '2022-06-03 22:39:05', 6, 'tesz', '126.00', 1, '127.00', 'Transacted'),
(9, 'Summer Car', '2022-06-03 22:39:44', 6, 'tesz', '126.00', 2, '255.00', 'Transacted'),
(10, 'Summer Car', '2022-06-06 01:52:56', 6, 'tesz', '126.00', 2, '255.00', 'Transacted'),
(11, 'Summer Car', '2022-06-06 01:54:35', 6, 'tesz', '126.00', 3, '400.00', 'Refunded'),
(12, 'Summer Car', '2022-06-06 01:59:00', 6, 'tesz', '126.00', 3, '400.00', 'Transacted'),
(13, 'Summer Car', '2022-06-14 20:57:06', 11, 'BRAKE PAD EVEREST LKC', '650.00', 1, '700.00', 'Transacted'),
(14, 'Summer Car', '2022-06-14 20:57:53', 11, 'BRAKE PAD EVEREST LKC', '650.00', 1, '700.00', 'Transacted'),
(15, 'Summer Car', '2022-06-14 20:58:57', 11, 'BRAKE PAD EVEREST LKC', '650.00', 2, '1400.00', 'Transacted'),
(16, 'Patrick De Guzman', '2022-06-14 21:27:55', 15, 'BRAKE PAD RANGER TRR', '500.00', 1, '600.00', 'Transacted'),
(17, 'Patrick De Guzman', '2022-06-14 21:31:44', 15, 'BRAKE PAD RANGER TRR', '500.00', 1, '500.00', 'Transacted'),
(18, 'Patrick De Guzman', '2022-06-14 21:33:39', 15, 'BRAKE PAD RANGER TRR', '500.00', 1, '600.00', 'Transacted');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `log_user` varchar(100) NOT NULL,
  `log_action` varchar(100) NOT NULL,
  `log_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `log_user`, `log_action`, `log_date`) VALUES
(1, 'Summer Car', 'Archived Supplier: suppz', '2022-06-02 19:19:28'),
(3, 'Summer Car', 'Transaction Completed OR Number: 1', '2022-06-02 19:26:46'),
(4, 'Summer Car', 'Transaction Completed OR Number: 1', '2022-06-02 19:29:14'),
(5, 'Summer Car', 'Transaction Completed OR Number: 1', '2022-06-02 19:29:48'),
(6, 'Username: summer', 'Logged In', '2022-06-03 01:00:47'),
(7, 'Username: ralfy', 'Logged In', '2022-06-03 01:06:15'),
(8, 'Username: pat', 'Logged In', '2022-06-03 01:06:37'),
(9, 'Username: summer', 'Logged In', '2022-06-03 01:06:42'),
(10, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 02:15:14'),
(11, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 02:16:32'),
(12, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 02:17:53'),
(13, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 02:17:57'),
(14, 'Summer Car', 'Transaction Completed OR Number: 2', '2022-06-03 02:38:55'),
(15, 'Summer Car', 'Transaction Completed OR Number: 3', '2022-06-03 02:57:48'),
(16, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:55:12'),
(17, 'Summer Car', 'Refunded Product ID: 6', '2022-06-03 04:55:21'),
(18, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 04:57:21'),
(19, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-03 04:57:22'),
(20, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:58:16'),
(21, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 04:58:55'),
(22, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 04:59:08'),
(23, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:08'),
(24, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 04:59:09'),
(25, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:19'),
(26, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:22'),
(27, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:24'),
(28, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:28'),
(29, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:44'),
(30, 'Summer Car', 'Refunded Product ID: 6', '2022-06-03 04:59:45'),
(31, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-03 04:59:45'),
(32, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:46'),
(33, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:46'),
(34, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:47'),
(35, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:47'),
(36, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:48'),
(37, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:48'),
(38, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:48'),
(39, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:48'),
(40, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 04:59:48'),
(41, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:00:02'),
(42, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:00:22'),
(43, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:00:23'),
(44, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:00:23'),
(45, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:00:29'),
(46, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 05:01:04'),
(47, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:01:08'),
(48, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 05:01:30'),
(49, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:01:40'),
(50, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 05:01:41'),
(51, 'Summer Car', 'Refunded Product ID: 2', '2022-06-03 05:02:25'),
(52, 'Summer Car', 'Unrefunded Product ID: 2', '2022-06-03 05:02:31'),
(53, 'Username: pat', 'Logged In', '2022-06-03 05:04:34'),
(54, 'Patrick De Guzman', 'Transaction Completed OR Number: 4', '2022-06-03 05:20:42'),
(55, 'Patrick De Guzman', 'Transaction Completed OR Number: 5', '2022-06-03 05:22:15'),
(56, 'Username: ralfy', 'Logged In', '2022-06-03 05:30:38'),
(57, 'Username: ralfy', 'Logged In', '2022-06-03 05:31:07'),
(58, 'Username: pat', 'Logged In', '2022-06-03 05:32:43'),
(59, 'Username: summer', 'Logged In', '2022-06-03 05:39:36'),
(60, 'Username: ralfy', 'Logged In', '2022-06-03 05:41:05'),
(61, 'Ralfy Bajao', 'Edit User ID: 3', '2022-06-03 06:02:19'),
(62, 'Ralfy Bajao', 'Edit User ID: 3', '2022-06-03 06:02:42'),
(63, 'Username: summer', 'Logged In', '2022-06-03 22:36:47'),
(64, 'Summer Car', 'Transaction Completed OR Number: 6', '2022-06-03 22:37:15'),
(65, 'Summer Car', 'Transaction Completed OR Number: 7', '2022-06-03 22:37:35'),
(66, 'Summer Car', 'Transaction Completed OR Number: 8', '2022-06-03 22:39:05'),
(67, 'Summer Car', 'Transaction Completed OR Number: 9', '2022-06-03 22:39:44'),
(68, 'Summer Car', 'Added Category: ', '2022-06-03 22:47:17'),
(69, 'Username: pat', 'Logged In', '2022-06-03 22:47:50'),
(70, 'Username: ralfy', 'Logged In', '2022-06-03 22:48:05'),
(71, 'Username: summer', 'Logged In', '2022-06-03 22:48:15'),
(72, 'Summer Car', 'Refunded Product ID: 6', '2022-06-03 22:48:43'),
(73, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-03 22:54:58'),
(74, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:17:33'),
(75, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:18:15'),
(76, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:18:25'),
(77, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:18:35'),
(78, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:19:01'),
(79, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:19:36'),
(80, 'Summer Car', 'Edit Category ID: 1', '2022-06-03 23:19:56'),
(81, 'Username: summer', 'Logged In', '2022-06-03 23:22:17'),
(82, 'Username: summer', 'Logged In', '2022-06-03 23:23:59'),
(83, 'Username: summer', 'Logged In', '2022-06-03 23:27:58'),
(84, 'Username: summer', 'Logged In', '2022-06-04 00:27:08'),
(85, 'Username: summer', 'Logged In', '2022-06-04 15:29:29'),
(86, 'Summer Car', 'Added Supplier: Supplier A', '2022-06-04 15:30:07'),
(87, 'Summer Car', 'Added Supplier: Supplier B', '2022-06-04 15:33:02'),
(88, 'Summer Car', 'Added Supplier: Supplier C', '2022-06-04 15:36:51'),
(89, 'Summer Car', 'Added Supplier: test', '2022-06-04 15:38:23'),
(90, 'Summer Car', 'Added Supplier: testdsadsa', '2022-06-04 15:39:11'),
(91, 'Summer Car', 'Refunded Product ID: dsxadsa', '2022-06-04 15:40:34'),
(92, 'Summer Car', 'Refunded Product ID: 6', '2022-06-04 15:40:59'),
(93, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-04 15:41:04'),
(94, 'Summer Car', 'Added Product: FUEL PUMP VIOS', '2022-06-04 15:44:33'),
(96, 'Username: pat', 'Logged In', '2022-06-04 15:48:19'),
(97, 'Username: summer', 'Logged In', '2022-06-06 01:49:41'),
(98, 'Summer Car', 'Transaction Completed OR Number: 10', '2022-06-06 01:52:56'),
(99, 'Summer Car', 'Transaction Completed OR Number: 11', '2022-06-06 01:54:35'),
(100, 'Summer Car', 'Refunded Product ID: 6', '2022-06-06 01:55:05'),
(101, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-06 01:55:14'),
(102, 'Summer Car', 'Refunded Product ID: 6', '2022-06-06 01:55:27'),
(103, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-06 01:55:33'),
(104, 'Summer Car', 'Refunded Product ID: 6', '2022-06-06 01:55:39'),
(105, 'Summer Car', 'Transaction Completed OR Number: 12', '2022-06-06 01:59:00'),
(106, 'Summer Car', 'Refunded Product ID: 6', '2022-06-06 01:59:42'),
(107, 'Summer Car', 'Unrefunded Product ID: 6', '2022-06-06 01:59:57'),
(108, 'Username: summer', 'Logged In', '2022-06-13 23:30:11'),
(109, 'Summer Car', 'Added Product: BRAKE PAD NAMRA', '2022-06-13 23:51:19'),
(110, 'Summer Car', 'Added Product: BRAKE PAD CITY NLS', '2022-06-13 23:52:43'),
(111, 'Summer Car', 'Added Product: BRAKE PAD RANGER TRR', '2022-06-13 23:53:16'),
(112, 'Username: ralfy', 'Logged In', '2022-06-13 23:54:39'),
(113, 'Username: summer', 'Logged In', '2022-06-14 20:49:11'),
(114, 'Summer Car', 'Archived Supplier: test', '2022-06-14 20:49:37'),
(115, 'Summer Car', 'Archived Supplier: testdsadsa', '2022-06-14 20:49:38'),
(116, 'Summer Car', 'Archived Supplier: dsxadsa', '2022-06-14 20:49:38'),
(117, 'Summer Car', 'Archived Supplier: Supplier', '2022-06-14 20:49:39'),
(118, 'Summer Car', 'Transaction Completed OR Number: 13', '2022-06-14 20:57:06'),
(119, 'Summer Car', 'Transaction Completed OR Number: 14', '2022-06-14 20:57:53'),
(120, 'Summer Car', 'Transaction Completed OR Number: 15', '2022-06-14 20:58:57'),
(121, 'Username: ralfy', 'Logged In', '2022-06-14 21:00:13'),
(122, 'Ralfy Bajao', 'Edit User ID: 3', '2022-06-14 21:00:49'),
(123, 'Username: patt', 'Logged In', '2022-06-14 21:00:54'),
(124, 'Patrick De Guzman', 'Edit User ID: 3', '2022-06-14 21:01:00'),
(125, 'Username: patt', 'Logged In', '2022-06-14 21:01:05'),
(126, 'Patrick De Guzman', 'Transaction Completed OR Number: 16', '2022-06-14 21:27:55'),
(127, 'Patrick De Guzman', 'Transaction Completed OR Number: 17', '2022-06-14 21:31:44'),
(128, 'Patrick De Guzman', 'Transaction Completed OR Number: 18', '2022-06-14 21:33:39'),
(129, 'Username: summer', 'Logged In', '2022-06-14 21:33:58'),
(130, 'Summer Car', 'Added 31 Quantity for: BRAKE PAD RANGER TRR', '2022-06-14 21:35:29'),
(131, 'Summer Car', 'Added 32 Quantity for: BRAKE PAD RANGER TRR', '2022-06-14 21:36:22');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(55) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_cost` decimal(10,2) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_category` varchar(55) NOT NULL,
  `product_barcode` varchar(55) NOT NULL,
  `product_status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_quantity`, `product_cost`, `product_price`, `product_category`, `product_barcode`, `product_status`) VALUES
(1, 'TEST', 10, '0.00', '120.00', 'CAT', 'BAR1', 'inactive'),
(2, 'test1', 10, '50.00', '100.00', 'TAC', 'BAR2', 'inactive'),
(3, 'test2test', 150, '0.00', '125.00', 'TAC', 'BAR3', 'inactive'),
(4, 'testtest', 5, '0.00', '150.00', 'TAC', 'BAR4', 'inactive'),
(5, 'testtt', 11, '50.00', '100.00', 'CAT', 'BAR5', 'inactive'),
(6, 'tesz', 82, '0.00', '126.00', 'CAT', 'BAR6', 'inactive'),
(7, 'jjj', 15, '70.00', '75.55', 'TAC', 'BAR7', 'inactive'),
(8, 'FUEL PUMP VIOS', 30, '3000.00', '3400.00', 'TAC', 'BAR8', 'active'),
(9, 'ABS SENSOR NABS-2203', 21, '1000.00', '1200.00', 'GORR', 'BAR9', 'active'),
(10, 'OXYGEN SENSOR WIGO', 17, '1000.00', '1300.00', 'GORR', 'BAR10', 'active'),
(11, 'BRAKE PAD EVEREST LKC', 9, '550.00', '650.00', 'NER', 'BAR11', 'active'),
(12, 'BRAKE PAD RANGER TRR', 11, '450.00', '500.00', 'TRR', 'BAR12', 'active'),
(13, 'BRAKE PAD NAMRA', 17, '425.00', '500.00', 'TRR', 'BAR13', 'active'),
(14, 'BRAKE PAD CITY NLS', 21, '600.00', '635.00', 'CAT', 'BAR14', 'active'),
(15, 'BRAKE PAD RANGER TRR', 32, '500.00', '550.00', 'TRR', 'BAR15', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `sales_date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `or_number` int(11) NOT NULL,
  `sales_price` decimal(10,2) NOT NULL,
  `sales_cost` decimal(10,2) NOT NULL,
  `sales_profit` decimal(10,2) NOT NULL,
  `sales_status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sales_date`, `product_id`, `or_number`, `sales_price`, `sales_cost`, `sales_profit`, `sales_status`) VALUES
(2, '2022-06-02', 2, 1, '100.00', '50.00', '50.00', 'Transacted'),
(3, '2022-06-03', 2, 2, '100.00', '50.00', '50.00', 'Transacted'),
(4, '2022-06-03', 6, 2, '126.00', '0.00', '126.00', 'Refunded'),
(5, '2022-06-03', 6, 3, '126.00', '0.00', '126.00', 'Transacted'),
(6, '2022-06-03', 2, 0, '100.00', '50.00', '50.00', 'Transacted'),
(7, '2022-06-03', 2, 0, '100.00', '50.00', '50.00', 'Transacted'),
(8, '2022-06-03', 6, 0, '126.00', '0.00', '126.00', 'Transacted'),
(9, '2022-06-03', 6, 0, '126.00', '0.00', '126.00', 'Transacted'),
(10, '2022-06-03', 6, 0, '126.00', '0.00', '126.00', 'Transacted'),
(11, '2022-06-03', 6, 0, '126.00', '0.00', '126.00', 'Transacted'),
(12, '2022-06-06', 6, 0, '126.00', '0.00', '126.00', 'Transacted'),
(13, '2022-06-06', 6, 0, '126.00', '0.00', '126.00', 'Transacted'),
(14, '2022-06-06', 6, 12, '126.00', '0.00', '126.00', 'Transacted'),
(15, '2022-06-14', 11, 13, '650.00', '550.00', '100.00', 'Transacted'),
(16, '2022-06-14', 11, 14, '650.00', '550.00', '100.00', 'Transacted'),
(17, '2022-06-14', 11, 15, '650.00', '550.00', '100.00', 'Transacted'),
(18, '2022-06-14', 15, 16, '500.00', '450.00', '50.00', 'Transacted'),
(19, '2022-06-14', 15, 17, '500.00', '450.00', '50.00', 'Transacted'),
(20, '2022-06-14', 15, 18, '500.00', '450.00', '50.00', 'Transacted');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `supplier_contact` varchar(11) NOT NULL,
  `supplier_email` varchar(55) NOT NULL,
  `supplier_status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_name`, `supplier_contact`, `supplier_email`, `supplier_status`) VALUES
(1, 'suppz', '09156113411', 'email1z@gmail.com', 'inactive'),
(2, 'abc', '09154061111', 'email2@gmail.com', 'inactive'),
(3, 'qwe', '09144444444', 'email3@gmail.com', 'inactive'),
(4, 'Supplier', '09145014321', 'emailz@gmail.com', 'inactive'),
(5, 'Supplier A', '63914507712', 'suppliera@gmail.com', 'active'),
(6, 'Supplier B', '63916502172', 'supplierb@gmail.com', 'active'),
(7, 'Supplier C', '63912432728', 'supplierc@gmail.com', 'active'),
(8, 'test', '22222', 'testss@gmail.com', 'inactive'),
(9, 'testdsadsa', '32163721', 'tesdsa@gmail.com', 'inactive'),
(10, 'dsxadsa', '321321321', 'testset@gmail.com', 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `product_barcode` varchar(55) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(55) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_amount` int(11) NOT NULL COMMENT 'quantity'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_firstname` varchar(55) NOT NULL,
  `user_lastname` varchar(55) NOT NULL,
  `user_username` varchar(55) NOT NULL,
  `user_password` varchar(55) NOT NULL,
  `user_position` varchar(55) NOT NULL,
  `user_status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_firstname`, `user_lastname`, `user_username`, `user_password`, `user_position`, `user_status`) VALUES
(1, 'Summer', 'Car', 'summer', '123', 'Manager', 'Active'),
(2, 'Ralfy', 'Bajao', 'ralfy', '123', 'Admin', 'Active'),
(3, 'Patrick', 'De Guzman', 'patt', '1234', 'Employee', 'Active'),
(4, 'Joseph', 'Paulo', 'paulo', '321', 'Admin', 'Inactive'),
(5, 'Khurt', 'Paraguya', 'khurt', '321', 'Employee', 'Inactive');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
