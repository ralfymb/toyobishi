<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
</head>
<body>
<link rel=stylesheet href=global.css>
<form method=POST action=>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>
<div class="mainHeader">
<div class="subHeader">
</div>
<div class="main">
    <center><input id="Search" type="text" class="search form-control" placeholder="Search Here"></center>
    <table id="myTable">
        <thead>
        <tr>
        <th>Product ID
        <th>Product Name
        <th>Quantity
        <th>Price
        <th>Total
        <th>Status
        <th>Action
        </tr>
        </thead>
        <tbody>
        <?php
        $or_number = $_GET['id'];
        $sql = "Select * from invoice where or_number = '$or_number'";
        $result = $con -> query($sql);

        while($row = $result-> fetch_assoc()){
            $total = $row['product_quantity'] * $row['product_price'];
        ?>
        <tr>
        <td><?php echo $row['product_id']; ?>
        <td><?php echo $row['product_name']; ?>
        <td><?php echo $row['product_quantity']; ?>
        <td><?php echo $row['product_price']; ?>
        <td><?php echo $total; ?>
        <td><?php echo $row['invoice_status']; ?>
        <?php 
        $prd_id=$row['product_id'];
        $or_no=$row['or_number'];
        ?>
        <?php 
        $sqlprd = "Select product_category from products WHERE product_id = $prd_id";
        $resultprd = $con->query($sqlprd);
        $rowprd = $resultprd->fetch_assoc();
        $pcat = $rowprd['product_category'];

        $sqlcat = "Select category_refund from categories WHERE category_name = '$pcat'";
        $resultcat = $con->query($sqlcat);
        $rowcat = $resultcat->fetch_assoc();
        $catref = $rowcat['category_refund'];
        ?>
        <td><?php if($catref == "Yes"){ if($row['invoice_status'] == "Transacted"){  echo "<a href='invoice_refund.php?pr_id=$prd_id&or_number=$or_no' style='text-decoration: none;'><font id=ReportBtn>Refund</font></a>"; }else if($row['invoice_status'] == "Refunded"){ echo "<a href='invoice_refund.php?pr_id=$prd_id&or_number=$or_no' style='text-decoration: none;'><font id=ReportBtn>Unrefund</font></a>";} }else{ echo "<font id=ReportBtn>Unrefundable</font>"; }?>
        <?php } ?>
        </tbody></table>
</div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('.search').on('keyup',function(){
        var searchTerm = $(this).val().toLowerCase(); //remove .toLowerCase() if is equals to what typed
        $('#myTable tbody tr').each(function(){
            var lineStr = $(this).text().toLowerCase();
            if(lineStr.indexOf(searchTerm) === -1){
                $(this).hide();
            }else{
                $(this).show();
            }
        });
    });
});
</script>