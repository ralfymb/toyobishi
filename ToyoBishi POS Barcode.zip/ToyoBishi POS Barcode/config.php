<?php

$servername="localhost";
$username="root";
$password="";
$dbase="system";


$con = new mysqli($servername,$username,$password,$dbase);

?>