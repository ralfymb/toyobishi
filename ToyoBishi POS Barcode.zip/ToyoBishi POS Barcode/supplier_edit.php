<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];

$ID = $_GET['id'];

$sql = "Select * from supplier where supplier_id = '$ID'";
$result = $con->query($sql);

$row = $result->fetch_assoc();

$esid = $row['supplier_id'];
$esname = $row['supplier_name'];
$escon = $row['supplier_contact'];
$esemail = $row['supplier_email'];
$esstatus = $row['supplier_status'];

$con->close();

?>
<html>
<head>
</head>
<body>
<form method =POST action=supplier_edit_final.php>
<link rel=stylesheet href=crud.css>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>

<div class="mainHeader">
    Edit Supplier
</div>

<div class="main">
    <input type=hidden name=sid value="<?php echo $esid;?>" readonly>
    <font class="font1">
    Supplier Name: <br> <input type=text name=sname value=<?php echo $esname;?>>
    <br><br>
    Supplier Contact: <br> <input type=text name=scon value=<?php echo $escon;?>>
    <br><br>
    Supplier Email: <br> <input type=text name=semail value=<?php echo $esemail;?>>
    <br><br>
    Product Status: </font> <br> 
    <?php
    if($esstatus == 'active'){
        ?> <input type=radio value="active" name=sstatus checked> <font class="font2">Active</font> <br> <input type=radio value="inactive" name=sstatus> <font class="font2">Inactive</font> <?php
    }if($esstatus == 'inactive'){
        ?> <input type=radio value="active" name=sstatus> <font class="font2">Active</font> <br> <input type=radio value="inactive" name=sstatus checked> <font class="font2">Inactive</font> <?php } ?>
    <br><br>
    <input type=submit name=sub value="Update Record" style="font-family:sans-serif;">
</div>
</form>
</body>
</html>