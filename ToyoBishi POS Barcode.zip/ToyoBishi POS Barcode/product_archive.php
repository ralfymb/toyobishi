<?php
include "config.php";
$ID = $_GET['id'];
$sql = "Select * from products WHERE product_id = $ID";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$stat = $row['product_status'];

if($stat == 'active'){
    $sql = "Update products SET product_status='inactive' where product_id = '$ID'";
}else if($stat == 'inactive'){
    $sql = "Update products SET product_status='active' where product_id = '$ID'";
}
$result = $con->query($sql);
header("refresh:0;url=product_list.php");
?>