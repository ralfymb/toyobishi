<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<?php

include "config.php";

if(!$con->connect_error){
	echo "Connected";
}

if(isset($_POST['sub'])){

    $pid = $_POST['pid'];
	$pname = $_POST['pname'];
    $pcategory = $_POST['pcategory'];
    $pprice = $_POST['pprice'];
    $pstatus = $_POST['pstatus'];
	
	$sql ="UPDATE products SET product_name = '$pname', product_category = '$pcategory', product_price = $pprice, product_status = '$pstatus' where product_id = $pid ";
	$result = $con->query($sql);
	
	if($result == True){
		$fulln = "$firstn $lastn";
		$sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Edited Product: $pname',NOW())";
		$insertlog = $con->query($sqllog);
	?>
	<script>
	alert("Successfully Updated")
	</script>
	<?php
	header("refresh:0;url=product_list.php");
	}else{
		echo $con->error;
	}
}

?>