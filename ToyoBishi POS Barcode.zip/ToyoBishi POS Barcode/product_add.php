<?php

include "config.php";
error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
</head>
<body>
<form method =POST action=product_add.php>
<link rel=stylesheet href=crud.css>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>

<div class="mainHeader">
    Add New Product
</div>
<!-- babaji -->
<div class="main">
    <font class="font1">
    Product Name: <br> <input type=text name=pname>
    <br><br>
    Product Quantity: <br> <input type=number name=pquantity>
    <br><br>
    Product Category: <br> <select style="font-size:1vw;font-family:sans-serif;width:13vw;" name=pcategory><?php $sql = "Select category_name from categories";
        $result = $con -> query($sql); 
        while($row = $result-> fetch_assoc()){ $cat = $row['category_name']; echo "<option value=$cat>$cat</option>"; }?></select>
    <br><br>
    Product Cost: <div class="tooltip"><img style="filter:invert(100%);width:1.5vw;height:1.5vw;" src=img/tooltip.png><span class="tooltiptext">Price paid for product</span></div> <br> <div class=currency><input style="width:11.5vw;" type=number name=pcost step=0.01></div>
    <br>
    Product Price: <div class="tooltip"><img style="filter:invert(100%);width:1.5vw;height:1.5vw;" src=img/tooltip.png><span class="tooltiptext">Set price for product</span></div> <br> <div class=currency><input style="width:11.5vw;" type=number name=pprice step=0.01></div>
    <br>
    Supplier: <br> <select style="font-size:1vw;font-family:sans-serif" name=psuppliers><?php $sql = "Select supplier_name from supplier WHERE supplier_status = 'active'";
        $result = $con -> query($sql); 
        while($row = $result-> fetch_assoc()){ $supp = $row['supplier_name']; echo "<option value=".$supp.">$supp</option>"; }?></select>
    <br><br>
    Product Status: </font><br> <input type=radio value="active" name=pstatus checked> <font class="font2">Active</font> <br> <input type=radio value="inactive" name=pstatus> <font class="font2">Inactive</font> 
    <br><br>
    <input type=submit name=sub value="Create New Product" style="font-family:sans-serif;">
</div>
</form>
</body>
</html>

<?php

include "config.php";

if(isset($_POST['sub'])){

$pname = $_POST['pname'];
$pquantity = $_POST['pquantity'];
$pcategory = $_POST['pcategory'];
$pcost = $_POST['pcost'];
$pprice = $_POST['pprice'];
$psuppliers = $_POST['psuppliers'];
$pstatus = $_POST['pstatus'];

$resultx = mysqli_query($con, "SELECT MAX(product_id) FROM products");
$row = mysqli_fetch_array($resultx);
$pid = $row[0]+1;

$pbar = $pid;
$pbarcode = str_pad($pbar, strlen($pbar) + 3, "BAR", STR_PAD_LEFT);

$sql = "Insert into products(product_name,product_quantity,product_category,product_cost,product_price,product_barcode,product_status) values ('$pname',$pquantity,'$pcategory',$pcost,$pprice,'$pbarcode','$pstatus')";
$sql1 = "Insert into inventory(product_id,inventory_quantity,inventory_input,inventory_cost,inventory_status,inventory_date) values ($pid,$pquantity,$pquantity,$pcost,'Supplier: $psuppliers',NOW())";
if(!$pname || !$pquantity || !$pcategory || !$pcost || !$pprice || !$psuppliers || !$pstatus){
	?>
<script>
	alert("Textfield can't be empty!")
</script>
<?php
}else
$insert = $con->query($sql);
$insert1 = $con->query($sql1);
$fulln = "$firstn $lastn";
$sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Added Product: $pname',NOW())";
$insertlog = $con->query($sqllog);
if($insert ==  True){
?>
<script>
	alert("Successfully Added!")
</script>
<?php
header("refresh:0;url=product_list.php");
}
}

?>