<html>
<head>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */

    }
</style>
</head>
<body onload="window.print();">
	<div style="margin-left: 5%">
		<?php
		include "config.php";
		include 'barcode_generate.php';
		$id = $_GET['id'];
		$sql = "Select * from products WHERE product_id = $id";
		$result = $con->query($sql);
		$row = $result->fetch_assoc();
		$stat = $row['product_status'];
		$product_name = $row['product_name'];
		$barcode = $row['product_barcode'];
		$product_id = $row['product_id'];
		$price = $row['product_price'];

		for($i=1;$i<=80;$i++){
			echo "<p class='inline'>".bar128(stripcslashes($barcode))."<span ><b>₱".$price." </b><span></p>&nbsp&nbsp&nbsp&nbsp";
		}

		?>
	</div>
</body>
</html>