<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<html>
<head>
</head>
<body>
<link rel=stylesheet href=global.css>
<form method=POST action=>
<style>
    a{
        margin-top: 5%;
        margin-bottom: 5%;
    }
</style>
<div class="sidenav">
    <center><img src=img/toyobishi.png style="width:8vw;height:5vw;"></center>
    <?php if($posn == "Manager"){ echo "<center><a href=main_manager.php>HOME</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=inventory_list.php>INVENTORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=product_list.php>PRODUCTS</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=sales.php>SALES</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=category_list.php>CATEGORY</a></center>"; } ?>
    <?php if($posn == "Manager" || $posn == "Employee"){ echo "<center><a href=transaction.php>TRANSACTION</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=supplier_list.php>SUPPLIER</a></center>"; } ?>
    <?php if($posn == "Manager"){ echo "<center><a href=invoice_list.php>INVOICE</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=users_list.php>USERS</a></center>"; } ?>
    <?php if($posn == "Admin"){ echo "<center><a href=logs.php>LOGS</a></center>"; } ?>
    <?php echo "<center><a href=logout.php>LOGOUT</a></center>"; ?>
</div>
<div class="mainHeader">
<?php if($posn == 'Manager'){ ?><a href='product_add.php' style='text-decoration: none;'><font class="Add">+ Add New Product</a></font><?php } ?>
<div class="subHeader">
Active<input type="radio" name="status" value="active" checked>
Inactive<input type="radio" name="status" value="inactive">
<input type=submit name=submit value="Sort" style="font-family:sans-serif;">
</div>
<div class="main">
    <center><input id="Search" type="text" class="search form-control" placeholder="Search Here"></center>
    <table id="myTable">
        <thead>
        <tr>
        <th>Product ID
        <th>Product Name
        <th>Product Quantity
        <th>Product Price
        <th>Product Category
        <th>Product Barcode
        <th>Product Status
        <th>Refundable
        <?php if($posn == 'Manager'){ ?><th>Action
        <?php } ?>
        </tr>
        </thead>
        <tbody>
        <?php
        if(isset($_POST['submit'])){
        $status = $_POST['status'];

        if($status == "active") {          
            $stat = 'active';
        }
        elseif($status == "inactive"){
            $stat = 'inactive';
        } }

        if(empty($stat)){
        $sql = "Select * from products WHERE product_status = 'active'";
        $result = $con -> query($sql);

        }else

        $sql = "Select * from products WHERE product_status = '$stat'";
        $result = $con -> query($sql);

        while($row = $result-> fetch_assoc()){

        ?>
        <tr>
        <td><?php echo $row['product_id']; ?>
        <td><?php echo $row['product_name']; ?>
        <?php if($row['product_quantity'] < 15) { echo "<td><font color=red><b>".$row['product_quantity']."</b></font>"; } else { echo "<td>".$row['product_quantity']; } ?>
        <td><?php echo $row['product_price']; ?>
        <td><?php echo $row['product_category']; ?>
        <td><?php echo "<a target=_blank href='barcode_display.php?id=".$row['product_id']."' style='text-decoration: none;'><font id=GenerateBtn>Generate</font></a>"; ?>
        <td><?php echo $row['product_status']; ?>
        <?php 
        $rwprdcat = $row['product_category'];
        //echo $rwprdcat;
        $sqlref = "Select * from categories WHERE category_name = '$rwprdcat'";
        $resultref = $con -> query($sqlref);

        while($rowref = $resultref-> fetch_assoc()){
        ?>
        <td><?php echo $rowref['category_refund']; } ?>
        <td><?php if($posn == 'Manager'){ echo "<a href='product_add_qty.php?id=".$row['product_id']."' style='text-decoration: none;'><font id=QtyBtn>AddQty</font></a>"; if($row['product_status'] == "active"){  echo "<a href='product_archive.php?id=".$row['product_id']."' style='text-decoration: none;'><font id=ArchiveBtn>Archive</font></a>"; }else if($row['product_status'] == "inactive"){ echo "<a href='product_archive.php?id=".$row['product_id']."' style='text-decoration: none;'><font id=ArchiveBtn>Unarchive</font></a>"; } echo "<a href='product_edit.php?id=".$row['product_id']."' style='text-decoration: none;'><font id=EditBtn>Edit</font></a>"; }?>
        <?php } ?>
    </tbody></table>
</div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('.search').on('keyup',function(){
        var searchTerm = $(this).val().toLowerCase(); //remove .toLowerCase() if is equals to what typed
        $('#myTable tbody tr').each(function(){
            var lineStr = $(this).text().toLowerCase();
            if(lineStr.indexOf(searchTerm) === -1){
                $(this).hide();
            }else{
                $(this).show();
            }
        });
    });
});
</script>