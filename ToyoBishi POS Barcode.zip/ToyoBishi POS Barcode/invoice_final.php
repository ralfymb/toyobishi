<?php

include "config.php";
//error_reporting(0);

session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$usern = $row['user_username'];
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
?>
<?php

include "config.php";

$sqlMax = mysqli_query($con,"SELECT MAX(or_number) AS max FROM invoice");
    $rowMax = mysqli_fetch_array($sqlMax);
    $or_number = $rowMax['max'] + 1;

if(isset($_POST['sub'])){
    $fulln = $_POST['fulln'];
    $cash = $_POST['cash'];

    $sqltransact = "Select * from transaction";
    $resulttransact = $con -> query($sqltransact);
    if($resulttransact -> num_rows > 0){
        while($rowtransact = $resulttransact-> fetch_assoc()){
            $transact_prod_id = $rowtransact['product_id'];
            $transact_prod_name = $rowtransact['product_name'];
            $transact_prod_price = $rowtransact['product_price'];
            $transact_prod_quantity = $rowtransact['product_amount'];

            $sql = "Select product_cost from products WHERE product_id = $transact_prod_id";
            $result = $con->query($sql);
            $row = $result->fetch_assoc();
            $cost = $row['product_cost'];
            $profit = $transact_prod_price - $cost;

            $sqlinvoice = "Insert into invoice(or_number,invoice_cashier,invoice_date,product_id,product_name,product_price,product_quantity,invoice_cash,invoice_status) values ($or_number,'$fulln',NOW(),$transact_prod_id,'$transact_prod_name',$transact_prod_price,$transact_prod_quantity,$cash,'Transacted')";
            $insertinvoice = $con->query($sqlinvoice);

            $sqlsales = "Insert into sales(sales_date,product_id,sales_price,sales_cost,sales_profit,sales_status,or_number) values (NOW(),$transact_prod_id,$transact_prod_price,$cost,$profit,'Transacted',$or_number)";
            $insertsales = $con->query($sqlsales);

            $sql7 = "SELECT * FROM inventory WHERE product_id = '$transact_prod_id' ORDER BY inventory_id DESC LIMIT 1";
            $result7 = $con->query($sql7);
            $row7 = $result7->fetch_assoc();
            $invquan = $row7['inventory_quantity'];
            $inventquan = $transact_prod_quantity - $invquan;
            $invv = abs($inventquan);

            $sql8 = "Insert into inventory(product_id,inventory_quantity,inventory_output,inventory_cost,inventory_status,inventory_date) values ($transact_prod_id,$invv,$transact_prod_quantity,$cost,'Cashier: $fulln',NOW())";
	        $insert8 = $con->query($sql8);

            $sql9 = "Update products set product_quantity=(product_quantity - $transact_prod_quantity) WHERE product_id = $transact_prod_id";
            $result9 = $con -> query($sql9);
        }
            $sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Transaction Completed OR Number: $or_number',NOW())";
            $insertlog = $con->query($sqllog);
            $sql10 = "TRUNCATE TABLE transaction"; //delete rows in table
            $insert10 = $con->query($sql10);
            header("refresh:0;url=transaction.php");
    }
}
?>