<?php
include "config.php";
$ID = $_GET['id'];
$sql = "Select * from supplier WHERE supplier_id = $ID";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$stat = $row['supplier_status'];
$sname = $row['supplier_name'];
session_start();
$sql = "Select * from users WHERE user_id = '$_SESSION[userid]'";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$firstn = $row['user_firstname'];
$lastn = $row['user_lastname'];
$posn = $row['user_position'];
$fulln = "$firstn $lastn";
if($stat == 'active'){
    $sql = "Update supplier SET supplier_status='inactive' where supplier_id = '$ID'";
}else if($stat == 'inactive'){
    $sql = "Update supplier SET supplier_status='active' where supplier_id = '$ID'";
}
$sqllog = "Insert into logs(log_user,log_action,log_date) values ('$fulln','Archived Supplier: $sname',NOW())";
$insertlog = $con->query($sqllog);
$result = $con->query($sql);
header("refresh:0;url=supplier_list.php");
?> 